export class Hero {
  id: number;
  name: string;
  dob:string;
  gender:string;
  diagnosis:string;
  gmfcs_level:string;
  caregiver_name:string;
  contact:string;
  residential_area:string;
  stand_id:string;
}
