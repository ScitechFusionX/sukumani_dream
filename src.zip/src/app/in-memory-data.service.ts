import { InMemoryDbService } from 'angular-in-memory-web-api';
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const heroes = [
  { id: 0, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 1, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 2, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 3, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 0, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 1, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 2, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' },
  { id: 3, name: 'Mr. Nice', dob:'19/06/2000', gender: 'Male', diagnosis: 'True',gmfcs_level: '7',caregiver_name: 'Samuel Norrs',contact:'0875596636', residential_area:'Tshimologong' }
  
    ];
    return {heroes};
  }
}
